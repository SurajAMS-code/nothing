import Remote.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

//Client
public class Client{
  public static void main(String[] args) throws IOException {
    RemoteControl control = new RemoteControl();
    Light light = new Light();
    Command lightsOn;//= new LightOnCommand(light);
    Command lightsOff;//= new LightOffCommand(light);

    System.out.println("Enter Light Command: ");
// Enter data using BufferReader
    BufferedReader reader = new BufferedReader(
            new InputStreamReader(System.in));

    // Reading data using readLine
    String name = reader.readLine();


    if(name.toLowerCase().equals("on"))
    {
      lightsOn = new LightOnCommand(light);
      control.setCommand(lightsOn);
      control.pressButton();
    }else
    {
      lightsOff = new LightOffCommand(light);
      control.setCommand(lightsOff);
      lightsOff.execute();
    }

  }
}


