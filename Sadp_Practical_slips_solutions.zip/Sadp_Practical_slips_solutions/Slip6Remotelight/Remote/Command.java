package Remote;
//Command
public interface Command
{
  public void execute();
}
