import SingletonPackage.*;

public class SingletonTestDrive {
	public static void main(String[] args) {
		Singleton foo = CoolerSingleton.getInstance();
		Singleton bar = HotterSingleton.getInstance();

		System.out.println(foo);
		System.out.println(bar);


		Singleton_new single = Singleton_new.getInstance();
		Singleton_new single2 = Singleton_new.getInstance();

		System.out.println(single);
		System.out.println(single2);

 	}
}
