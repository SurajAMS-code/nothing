public class Singleton_new {
	public static Singleton_new uniqueInstance;

	// other useful instance variables here

	private Singleton_new() {

		System.out.println("This is new singleton");
	}
 
	public static synchronized Singleton_new getInstance() {
		if (uniqueInstance == null) {
			uniqueInstance = new Singleton_new();
		}
		return uniqueInstance;
	}
 
	// other useful methods here
}