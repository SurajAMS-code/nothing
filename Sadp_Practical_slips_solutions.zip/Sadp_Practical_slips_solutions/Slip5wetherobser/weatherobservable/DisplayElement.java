package weatherobservable;

public interface DisplayElement {
	public void display();
}
