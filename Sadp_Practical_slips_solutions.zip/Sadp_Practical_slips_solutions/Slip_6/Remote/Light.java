package Remote;
//Receiver
public class Light{
   public void switchOn(){
    System.out.println("Light is turned on");
  }
  public void switchOff(){
    System.out.println("Light is turned off");
  }
}
